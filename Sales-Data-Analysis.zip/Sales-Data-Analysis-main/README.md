# 📊 Sales Data Analysis

## 📌 Project Overview
This project analyzes sales data to uncover insights about revenue, profit, and product performance.

## 🛠 Tools Used
- Python
- Pandas
- Matplotlib
- Seaborn

## 📈 Key Insights
- Technology category has highest sales
- Some sub-categories are generating losses
- Top products contribute most revenue

## 📁 Dataset
Sales dataset used for analysis

## 👩‍💻 Author
Shatakshi Kharwadkar
